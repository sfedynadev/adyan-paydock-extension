export default JSON.stringify({
  status: 422,
  errorCode: '172',
  message: 'Encrypted data used outside of valid time period',
  errorType: 'validation',
})
